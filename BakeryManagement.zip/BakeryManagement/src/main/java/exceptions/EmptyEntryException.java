package exceptions;

public class EmptyEntryException extends Exception{
	
	public EmptyEntryException() {
		super("Empty Input is NOT accepted.");
	}
}
