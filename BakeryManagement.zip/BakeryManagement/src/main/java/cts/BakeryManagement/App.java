package cts.BakeryManagement;

import cts.BakeryManagement.Services.*;
import java.util.Scanner;

import cts.BakeryManagement.Services.UserLogin;
import cts.BakeryManagement.Services.UserRegistration;

/**
 * Hello world!
 *
 */
public class App {
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		int loggedId = -1;
		while (true) {
			
			System.out.print(
					"1. Register \n2. Login \n3. Menu \n4. Order \n5.Display Price \nEnter your choice:");
			int c = sc.nextInt();
			System.out.println();

			
			switch (c) {
			case 1:
				UserRegistration manager = new UserRegistration();
				boolean b=true;
				do {
					System.out.println("1. Register User\nBelow functionalities for ADMIN use\n2. Insert Item\n3.Update Item\n4. Remove Item\n5. Back\nEnter your choice: ");
					int choice=sc.nextInt();
					switch(choice) {
					case 1:
						manager.registerUser();
						break;
					case 2:
						manager.insert();
						break;
					case 3:
						manager.updatePrice();
						break;
					case 4:
						manager.remove();
						break;
					case 5:
						b=false;
						break;
					default:
						System.out.println("Select the correct choice");
					}
				}while(b);
				
				System.out.println();
				break;

			case 2:
				System.out.println("Enter login Details:");
				System.out.print("ID : ");
				int id = sc.nextInt();
				System.out.print("Password : ");
				sc.nextLine();
				String pwd = sc.nextLine();
				if (UserLogin.login(id, pwd)) {
					System.out.println("Login Successfull.");
					loggedId = id;
				} else {
					System.out.println("Login failed.");
				}
				System.out.println();
				break;
			case 3:
				if(loggedId==-1) {
					System.out.println("Login to your account.");
					System.out.println();
					break;
				}
				else{
					Service.menu();
					}
				break;
			case 4:
				if(loggedId==-1) {
					System.out.println("Login to your account.");
					System.out.println();
					break;
				}else{Service.menu();
				Service.items();}
				
				System.out.println();
				break;
			case 5:
				if(loggedId==-1) {
					System.out.println("Login to your account.");
					System.out.println();
					break;
				}else {
				Service.displayPrice();}
				System.exit(0);
			default:
				break;
			}
		}
	}
}
