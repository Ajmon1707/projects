package cts.BakeryManagement.DAO;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import cts.BakeryManagement.Models.User;

public class UserDAO {

	static Connection con = ConnectionProvider.getCon();
	public boolean createAccount(User user) {
		try
		{
			
			String sql = "Insert INTO customer(name, age, mobile_number, address, password) Values(?,?,?,?,?);"; 
			PreparedStatement s = con.prepareStatement(sql);
			s.setString(1, user.getName());
			s.setInt(2, user.getAge());
			s.setLong(3, user.getMobileNumber());
			s.setString(4, user.getAddress());
			s.setString(5, user.getPassword());
			int a = s.executeUpdate();
			
			if(a == 1) {
				System.out.println("Registration Successfull.");
				sql = "select max(id) as id from customer"; 
				s = con.prepareStatement(sql);
				ResultSet rs = s.executeQuery();
				rs.next();
				System.out.println("Your registered id is "+ rs.getInt("id"));
				return true;
			}
			
			
		}catch(Exception e) {e.printStackTrace();System.out.print(e);}
		return false;
	}
	
	public boolean insert(String item,int price) {
		try {
			String query="insert into itemstable (items,price) values(?,?)";
			PreparedStatement s = con.prepareStatement(query);
			s.setString(1, item);
			s.setInt(2, price);
			s.execute();
			return true;
		}catch(SQLException e) {
			e.printStackTrace();
			return false;
		}
		
	}
	
	
	
	
	public boolean login(int id, String pwd) {
		String sql = "select * from customer where id = ? and password = ?;"; 
		try {
			PreparedStatement s = con.prepareStatement(sql);
			s.setInt(1, id);
			s.setString(2, pwd);
			ResultSet rs = s.executeQuery();
			
			return rs.next();
		}
		catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}

	public static void showMenu() {
		
		try {
			String query="select * from itemstable";
			PreparedStatement s = con.prepareStatement(query);
			ResultSet rs = s.executeQuery();
			System.out.println("S.No"+" ".repeat(5)+" ".repeat(5)+"Items "+" ".repeat(12)+"Price");
			System.out.println("-".repeat(40));
			while(rs.next()) {
				int id=rs.getInt("SNO");
				String item=rs.getString("items");
				int price=rs.getInt("price");
				System.out.println(id+" ".repeat(7)+" ".repeat(5)+item+" ".repeat(20-item.length())+price);
			}
			System.out.println("-".repeat(40));
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public static int getPrice(int choice) {
		int price = 0;
		try {
			String query="select price from itemstable where SNO=?";
			PreparedStatement s = con.prepareStatement(query);
			s.setInt(1,choice);
			ResultSet rs = s.executeQuery();
			
			while(rs.next()) {
				price=rs.getInt("price");
			}
			return price;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return price;
	}

	public boolean update(String item, int price) {
		try {
			String query="update itemstable set price=? where items=?";
			PreparedStatement s = con.prepareStatement(query);
			s.setInt(1, price);
			s.setString(2, item);
			
			s.execute();
			return true;
		}catch(SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public boolean remove(String item) {
		try {
			String query="delete from itemstable where items=?";
			PreparedStatement s = con.prepareStatement(query);
			s.setString(1, item);
			
			s.execute();
			return true;
		}catch(SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	public static String getItemName(int id) {
		try {
			String item = null;
			String query="select items from itemstable where SNO=?";
			PreparedStatement s = con.prepareStatement(query);
			s.setInt(1,id);
			ResultSet rs = s.executeQuery();
			
			while(rs.next()) {
				item=rs.getString("items");
			}
			return item;
		}catch(SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
}
