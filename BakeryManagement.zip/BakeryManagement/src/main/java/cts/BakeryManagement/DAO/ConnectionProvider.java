package cts.BakeryManagement.DAO;
import java.sql.*;

public class ConnectionProvider {
	public static Connection getCon() {
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bakerymanagement","root","root");
			return con;
		}
		catch(Exception e) {
			System.out.println("connection failed");
			return null;
		}
	}

}
