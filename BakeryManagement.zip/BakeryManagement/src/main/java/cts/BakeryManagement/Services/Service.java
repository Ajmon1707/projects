package cts.BakeryManagement.Services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import cts.BakeryManagement.DAO.UserDAO;


public class Service {
	static HashMap<String, Integer> hm = new HashMap<String, Integer>();
	static ArrayList<Integer> quantityArray=new ArrayList<Integer>();
	static Scanner sc = new Scanner(System.in);
	static int totalCost = 0; //it shows  total cost of all ordered items.

	public static void menu() {
		System.out.println();
		UserDAO.showMenu();
	}
	public static String getItemNames(int id) {
		String str="";
		str=UserDAO.getItemName(id);
		return str;
	}

	public static void items() {

		do {
			System.out.println("Select your choice: ");
			int choice = sc.nextInt();
			if (choice >= 1) {
				System.out.println("How many you want: ");
				int plates = sc.nextInt();
				int price = UserDAO.getPrice(choice);
				totalCost += plates * price;
				String item=getItemNames(choice);
				hm.put(item, price);

			}
//			 else if (choice > 2 && choice < 6) {
//				System.out.println("How many you want: ");
//				int plates = sc.nextInt();
//				int price = UserDAO.getPrice(choice);
//				totalCost += plates * price;
//				String item=getItemNames(choice);
//				hm.put(item, price);
//				}
		
			 else if (choice > 6) {
				System.out.println("Please select your choice based on the menu.");
			}
			System.out.println("Order again (y/n): ");
			char c = sc.next().charAt(0);
			if (c == 'n' || c == 'N') {
				break;
			} else if (c == 'y' || c == 'Y') {
				continue;
			}

		} while (true);

	}

	public static void displayPrice() {
		System.out.println("Total Price is: " + totalCost);
		System.out.println(hm);

	}
}
