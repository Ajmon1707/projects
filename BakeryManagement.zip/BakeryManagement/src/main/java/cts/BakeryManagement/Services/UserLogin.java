package cts.BakeryManagement.Services;

import cts.BakeryManagement.DAO.UserDAO;

public class UserLogin {
	public static boolean login(int id, String pwd) { //login method
		UserDAO obj = new UserDAO();
		return obj.login(id, pwd);
	}

}
