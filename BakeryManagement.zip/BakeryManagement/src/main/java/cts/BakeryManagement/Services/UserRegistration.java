package cts.BakeryManagement.Services;

import java.util.Scanner;

import cts.BakeryManagement.Models.User;
import exceptions.EmptyEntryException;
import cts.BakeryManagement.DAO.UserDAO;
public class UserRegistration {
	Scanner sc = new Scanner(System.in);
	
	private boolean isValid(User user) {
		// TODO Auto-generated method stub
		return true;
	}
	
	public void registerUser() {
		try{Validation valid= new Validation();
			System.out.println("Enter the registration details: ");
			System.out.print("Name : ");
			String name = valid.validateString();
			if(name.trim().equals("")) {throw new EmptyEntryException();}
			System.out.print("Age : ");
			int age = valid.validateIntValues("age");
			
			System.out.print("Phone Number : ");
			long phNo = valid.validateLongValues("phone");
			
			System.out.print("Address : ");
			String address = valid.validateString();
			
			System.out.print("Password : ");
			String pwd = valid.validatePassword();
			
			User user = new User(name, age, phNo, address, pwd);
			
			if(isValid(user)) {
				UserDAO obj = new UserDAO();
				obj.createAccount(user); //to store user account info
			}
			else {
				System.out.println("Invalid User Details.");
			}
		}catch(EmptyEntryException e) {
			System.out.println(e.getMessage());
		}
		
	}
	public void insert() {
		Validation valid= new Validation();
		System.out.println("Enter the item you want to add: ");
		String item=valid.validateString();
		System.out.println("Enter the price for the "+item);
		int price=valid.validateIntValues("Price");
		UserDAO userDAO = new UserDAO();
		boolean ab=userDAO.insert(item, price);
		if(ab) {
			System.out.println("Inserted successfully");
		}else {
			System.out.println("Insert unsuccessful");
		}
		
	}

	public void updatePrice() {
		Validation valid= new Validation();
		System.out.println("Enter the item you want to update: ");
		String item=valid.validateString();
		System.out.println("Enter the price to update ");
		int price=valid.validateIntValues("Price");
		UserDAO userDAO = new UserDAO();
		boolean ab=userDAO.update(item, price);
		if(ab) {
			System.out.println("updated successfully");
		}else {
			System.out.println("update unsuccessful");
		}
		
	}

	public void remove() {
		Validation valid= new Validation();
		System.out.println("Enter the item you want to update: ");
		String item=valid.validateString();
		UserDAO userDAO = new UserDAO();
		boolean ab=userDAO.remove(item);
		if(ab) {
			System.out.println("removed successfully");
		}else {
			System.out.println("remove unsuccessful");
		}
	}

	
}
