package cts.BakeryManagement.Services;
 
import java.util.Scanner;
 
public class Validation {
	static Scanner sc=new Scanner(System.in);
	public String validateString() {
		String name;
		boolean b = true;
		do {
			//sc.next();
			//sc.nextLine();
			name = sc.next();
			if (name.matches("^[a-zA-Z ]*$")) {
				b = false;
			} else {
				System.out.println("Enter your name only in Alphabets");
			}
		} while (b);
		return name;
	}
	public int validateIntValues(String str) {
		int value = 0;
		boolean b = true;
		do {
			while (!sc.hasNextInt()) {
				System.out.println("Please enter correct " + str);
				sc.next();
			}
			value = sc.nextInt();
			b = false;
		} while (b);
		return value;
	}
	public String validatePassword() {
			String pattern;
			boolean b = true;
			do {
				pattern = sc.next();
				if (pattern.matches("(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}")) {
					b = false;
				} else {
					System.out.println("Please enter one (upper,lower,specialchars,number) minimum 8 characters");
				}
			} while (b);
			return pattern;
		}
	public long validateLongValues(String str) {
			long value = 0;
			boolean b = true;
			do {
				while (!sc.hasNextLong()) {
					System.out.println("Please enter correct " + str);
					sc.next();
				}
				value = sc.nextLong();
				if (String.valueOf(value).length() == 10) {
					String value1=String.valueOf(value);
					if(value1.charAt(0)=='9' || value1.charAt(0)=='8' || value1.charAt(0)=='7' || value1.charAt(0)=='6') {
					b = false;
					}else {
						System.out.println("Please enter   mobile starting with 9,8,7,6");
					}
				} else {
					System.out.println("Please enter 10-digits only.");
				}
			} while (b);
			return value;
		}










}
