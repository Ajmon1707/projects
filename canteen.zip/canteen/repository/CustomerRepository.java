package com.canteen.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.canteen.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

	@Query("from Customer where id = (select max(id) from Customer)")
	List<Customer> getRegisteredCustomer();

}
