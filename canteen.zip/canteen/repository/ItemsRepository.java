package com.canteen.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.canteen.entity.Items;

import jakarta.transaction.Transactional;

public interface ItemsRepository extends JpaRepository<Items, Integer> {
	
	@Modifying
	@Transactional
	@Query("update Items set availableQuantity = availableQuantity - :quantity where itemId = :id")
	void reduceQuantity(@Param("id") int itemId, @Param("quantity") int availableQuantity);

}
