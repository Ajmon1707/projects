package com.canteen.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.canteen.entity.Orders;

public interface OrdersRepository extends JpaRepository<Orders, Integer> {

	@Query("select o from Orders o where o.orderId = (select max(orderId) from Orders)")
	List<Orders> findMyOrderId();

	List<Orders> findByCustomerId(int id);

}
