package com.canteen.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.canteen.entity.Customer;
import com.canteen.entity.Items;
import com.canteen.entity.Orders;
import com.canteen.service.CanteenService;

import jakarta.validation.Valid;

@Controller
@SessionAttributes({"customerId","adminLoggedIn"})
public class CanteenController {
	
	@Autowired
	CanteenService canteenService;
	
	@GetMapping("")
	public String home() {
		return "home";
	}
	
	@GetMapping("register")
	public String registerCustomerPage(@ModelAttribute Customer customer) {
		return "register";
	}
	
	@PostMapping("register")
	public String doRegisterCustomer(@Valid Customer customer,BindingResult result, ModelMap model) {
		if(result.hasErrors()) {
			return "register";
		}
		int id = canteenService.registerCustomer(customer);
		model.put("id",id);
		return "registration_success_page";
	}
	
	@GetMapping("/login")
	public String loginPage() {
		return "login_page";
	}
	
	@GetMapping("/admin_login")
	public String adminLoginPage() {
		return "admin_login";
	}
	
	@PostMapping("/admin_login")
	public String doAdminLogin(@RequestParam String adminUsername, @RequestParam String password, ModelMap model) {
		if(adminUsername.equals("admin") && password.equals("admin")) {
			model.put("adminLoggedIn", true);
			return "redirect:admin";
		}
		else {
			model.put("invalid", "Invalid Credentials");
			return "admin_login";
		}
		
	}
	
	@GetMapping("admin")
	public String adminHomePage(ModelMap model) {
		if(model.get("adminLoggedIn")!=null && (boolean)model.get("adminLoggedIn")) {
			return "admin_home";
		}
		else {
			return "admin_login";
		}
		
	}
	
	@GetMapping("/customer_login")
	public String customerLoginPage() {
		return "customer_login";
	}
	
	@PostMapping("/customer_login")
	public String doLogin(@RequestParam int customerID, @RequestParam String password, ModelMap model) {
		String view="";
		if(canteenService.customerLogin(customerID, password)) {
			model.put("customerId", customerID);
			view = "redirect:customer";
		}
		else {
			view = "customer_login";
			model.put("invalid", "Invalid Credentials.");
		}
		return view;
	}
	
	@GetMapping("customer")
	public String customerHomePage(ModelMap model) {
		if(model.get("customerId")!=null) {
			return "customer_home";
		}
		return "redirect:customer_login";
	}
	
	@GetMapping("admin/add_item")
	public String addItemPage(@ModelAttribute("item") Items item, ModelMap model) {
		if(model.get("adminLoggedIn")!=null && (boolean)model.get("adminLoggedIn")) {
			return "add_item";
		}
		else {
			return "redirect:/admin_login";
		}
	}
	
	@PostMapping("admin/add_item")
	public String addItem(@Valid Items item, BindingResult result, ModelMap model) {
		if(result.hasErrors()) {
			return "add_item";
		}
		canteenService.addItem(item);
		model.put("operation", "Added");
		return "admin_operation_page";
	}
	
	@GetMapping("admin/remove_item")
	public String removeItemPage(ModelMap model) {
		if(model.get("adminLoggedIn")!=null && (boolean)model.get("adminLoggedIn")) {
			List<Items> items = canteenService.getAllItems();
			model.put("items", items);
			return "remove_item";
		}
		else {
			return "redirect:/admin_login";
		}
	}
	
	@GetMapping("admin/remove_item_by_id")
	public String removeItem(@RequestParam int itemId, ModelMap model) {
		canteenService.removeItem(itemId);
		model.put("operation", "Removed");
		return "admin_operation_page";
	}
	
	@GetMapping("admin/update_item")
	public String updateItemPage(ModelMap model) {
		if(model.get("adminLoggedIn")!=null && (boolean)model.get("adminLoggedIn")) {
			List<Items> items = canteenService.getAllItems();
			model.put("items", items);
			return "update_item";
		}
		else {
			return "redirect:/admin_login";
		}
	}
	
	@GetMapping("admin/update_item_by_id")
	public String updateItemPage(@RequestParam int itemId, ModelMap model) {
		Items item = canteenService.getItemById(itemId);
		
		model.put("item", item);
		return "updatePage";
	}
	
	@PostMapping("admin/update_item_by_id")
	public String updateItem(@Valid Items item,BindingResult result, ModelMap model) {
		if(result.hasErrors()) {
			model.put("item", item);
			return "updatePage";
		}
		canteenService.addItem(item);
		model.put("operation", "Updated");
		return "admin_operation_page";
	}
	
	
	
	@GetMapping("customer/show_items")
	public String showItems(ModelMap model) {
		List<Items> items = canteenService.getAllItems();
		model.put("items", items);
		return "show_items_page";
	}
	
	@GetMapping("/order")
	public String orderPage(@ModelAttribute("order") Orders order, ModelMap model) {
		List<Items> items = canteenService.getAllItems();
		model.put("itemsList", items);
		return "ordersPage";
	}
	
	@PostMapping("/order")
	public String order(Orders order, ModelMap model) {
		Customer customer= canteenService.getCustomerById(model.get("customerId").toString());
		String res= canteenService.makeOrder(order, customer);
		if(res.equals("DONE")) {
			return "redirect:/order/showBill";
		}
		else {
			List<Items> items = canteenService.getAllItems();
			model.put("itemsList", items);
			model.put("error", res);
			model.put("order", order);
			return "ordersPage";
		}
		
	}
	
	@GetMapping("/order/showBill")
	public String showBill(ModelMap model) {
		Customer customer= canteenService.getCustomerById(model.get("customerId").toString());
		int orderId = canteenService.getMyOrderId(customer);
		Orders order = canteenService.getOrderDetails(orderId);
		model.put("order", order);
		return "bill";
	}
	 
	@GetMapping("/customer/history")
	public String showHistory(ModelMap model) {
		List<Orders> orders = canteenService.getAllMyOrders(Integer.parseInt(model.get("customerId").toString()));
		model.put("orders", orders);
		return "history";
	}
	
}
