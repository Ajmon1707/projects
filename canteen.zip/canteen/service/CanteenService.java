package com.canteen.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.canteen.entity.Customer;
import com.canteen.entity.Items;
import com.canteen.entity.OrderedItems;
import com.canteen.entity.Orders;
import com.canteen.repository.CustomerRepository;
import com.canteen.repository.ItemsRepository;
import com.canteen.repository.OrdersRepository;

@Service
public class CanteenService {
	@Autowired
	CustomerRepository custRepo;
	
	@Autowired
	ItemsRepository itemsRepo;
	
	@Autowired
	OrdersRepository ordersRepo;
	
	public int registerCustomer(Customer customer) {
		custRepo.save(customer);
		Customer cust = custRepo.getRegisteredCustomer().get(0);
		return cust.getId();
	}

	public boolean customerLogin(int customerID, String password) {
		Optional<Customer> customer = custRepo.findById(customerID);
		
		if(customer.isPresent() && customer.get().getPassword().equals(password)) {
			return true;
		}
		else {
			return false;
		}
	}

	public void addItem(Items item) {
		itemsRepo.save(item);
	}

	public void removeItem(int itemId) {
		itemsRepo.deleteById(itemId);		
	}

	public List<Items> getAllItems() {
		List<Items> items = itemsRepo.findAll();
		return items;
	}

	public Items getItemById(int itemId) {
		return itemsRepo.findById(itemId).get();
	}

	public Customer getCustomerById(String string) {
		Customer customer = custRepo.findById(Integer.parseInt(string)).get();
		return customer;
	}

	public String makeOrder(Orders order, Customer customer) {
		order.setOrderId(0);
		List<OrderedItems> myItems = new ArrayList<>();
		float totalPrice=0;
		for(OrderedItems orderItem: order.getItems()) {
			if(orderItem.getQuantity()>0) {
				
				Items myItem = getItemById(orderItem.getItem().getItemId());
				orderItem.setItem(myItem);
				if(orderItem.getQuantity() > orderItem.getItem().getAvailableQuantity()) {
					return "Available Quantity of " +  orderItem.getItem().getItemName() + " is only "+ orderItem.getItem().getAvailableQuantity();
				}
				orderItem.setId(0);
				orderItem.setOrder(order);
				myItems.add(orderItem);
				totalPrice += orderItem.getQuantity()*orderItem.getItem().getPrice();
			}
		}
		if(myItems.size()==0) {
			return "No Items Selected";
		}
		order.setItems(myItems);
		order.setCustomer(customer);
		order.setTotalPrice(totalPrice);
		ordersRepo.save(order);
		for(OrderedItems item:myItems) {
			itemsRepo.reduceQuantity(item.getItem().getItemId(), item.getQuantity());
		}
		return "DONE";
	}

	public int getMyOrderId(Customer customer) {
		int orderId = ordersRepo.findMyOrderId().get(0).getOrderId();
		return orderId;
	}

	public Orders getOrderDetails(int orderId) {
		Orders order = ordersRepo.findById(orderId).get();
		return order;
	}

	public List<Orders> getAllMyOrders(int id) {
		List<Orders> orders = ordersRepo.findByCustomerId(id);
		return orders;
	}
	
	
	
}
