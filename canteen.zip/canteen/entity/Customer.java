package com.canteen.entity;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "customer")
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Min(value=1, message="Age should be positive")
	private Integer age;
	
	@Size(min=1, message="Name is required")
	private String name;
	
	
	private Long mobileNumber;
	
	@Size(min=1, message="Address is required")
	private String address;
	
	@Size(min=1, message="Password is required")
	private String password;
	
	
	
	@OneToMany(mappedBy="customer", cascade = CascadeType.ALL)
	List<Orders> custOrders;

	public List<Orders> getCustOrders() {
		return custOrders;
	}

	public void setCustOrders(List<Orders> custOrders) {
		this.custOrders = custOrders;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Customer(Integer id, Integer age, String name, Long mobileNumber, String address, String password) {
		super();
		this.id = id;
		this.age = age;
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.address = address;
		this.password = password;
	}

	public Customer() {
		super();
	}

}
