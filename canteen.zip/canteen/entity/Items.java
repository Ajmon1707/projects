package com.canteen.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "items_table")
public class Items {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int itemId;

    @Column(nullable = false)
    @Size(min=1,message="Item Name is required.")
    private String itemName;

    @Column(nullable = false)
    @Min(value=1,message="Price is required.")
    private Float price;

    @Column(nullable = false)
    @Min(value=1,message="Quantity is required.")
    private Integer availableQuantity;

    
	@Override
	public String toString() {
		return "Items [itemId=" + itemId + ", itemName=" + itemName + ", price=" + price + ", availableQuantity="
				+ availableQuantity + "]";
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public Integer getAvailableQuantity() {
		return availableQuantity;
	}

	public void setAvailableQuantity(Integer availableQuantity) {
		this.availableQuantity = availableQuantity;
	}

	public Items(int itemId, String itemName, Float price, Integer availableQuantity) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.price = price;
		this.availableQuantity = availableQuantity;
	}
	
	public Items() {
		
	}

}
